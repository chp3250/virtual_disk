#include "stdafx.h"
#include "CVirtualDisk.h"


CVirtualDisk::CVirtualDisk()
{
	Clear();
}

CVirtualDisk::~CVirtualDisk()
{

}