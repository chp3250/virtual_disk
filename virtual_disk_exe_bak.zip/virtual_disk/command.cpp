#include "stdafx.h"
#include "command.h"

CDir::CDir()
{

}
CDir::~CDir()
{

}

int CDir::Exec()
{
	return 0;
}